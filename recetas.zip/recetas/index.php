<?php
header('Location: /public/login.php');
exit;
